import * as React from "react";
const SvgCallReceived = props => /*#__PURE__*/React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  ...props
}, /*#__PURE__*/React.createElement("path", {
  d: "M20 5.41 18.59 4 7 15.59V9H5v10h10v-2H8.41L20 5.41z",
  fill: "currentColor"
}));
export default SvgCallReceived;