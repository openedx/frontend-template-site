import * as React from "react";
const Svg2Mp = props => /*#__PURE__*/React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  ...props
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 3v18h18V3H3zm7 5h3V7h-3V5.5h4.5V9h-3v1h3v1.5H10V8zm2.5 10.5H11V14h-1v3H8.5v-3h-1v4.5H6v-6h6.5v6zM18 17h-3v1.5h-1.5v-6H18V17z",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("path", {
  d: "M15 14h1.5v1.5H15z",
  fill: "currentColor"
}));
export default Svg2Mp;