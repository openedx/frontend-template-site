import * as React from "react";
const Svg8Mp = props => /*#__PURE__*/React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  ...props
}, /*#__PURE__*/React.createElement("path", {
  d: "M15 14h1.5v1.5H15zm-3.5-7.5H13V8h-1.5z",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("path", {
  d: "M3 3v18h18V3H3zm7 2.5h4.5v6H10v-6zm2.5 13H11V14h-1v3H8.5v-3h-1v4.5H6v-6h6.5v6zM18 17h-3v1.5h-1.5v-6H18V17z",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("path", {
  d: "M11.5 9H13v1.5h-1.5z",
  fill: "currentColor"
}));
export default Svg8Mp;